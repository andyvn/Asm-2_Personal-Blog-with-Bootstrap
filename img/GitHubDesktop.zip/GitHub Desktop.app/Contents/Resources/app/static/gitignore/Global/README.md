## Globally Useful gitignores

This directory contains globally useful gitignores,
e.g. OS-specific and editor specific.

For more on global gitignores:
<https://help.github.com/articles/ignoring-files/#create-a-global-gitignore>

And a good blog post about 'em:
<http://augustl.com/blog/2009/global_gitignores>
